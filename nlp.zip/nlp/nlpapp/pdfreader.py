# import datetime
# import pyPdf
# pdf = pyPdf.PdfFileReader(open("C:\\Users\\Reema\\PycharmProjects\\nlp\\media", "rb"))
# s=""
# for page in pdf.pages:
#     s=s+page.extractText()
# print(s)
#
#
#
# import docx
# s="C:\\Users\\Reema\\PycharmProjects\\nlp\\media\\"
# doc = docx.Document(filename)
# fullText = []
# for para in doc.paragraphs:
#     fullText.append(para.text)
#     s=s+ para.text
#
#
#
#
#
#
#
#
